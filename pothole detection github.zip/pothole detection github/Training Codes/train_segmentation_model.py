#!/usr/bin/env python3
"""
Train YOLOv8 Segmentation Model for Pothole Detection
"""

import os
import cv2
import numpy as np
import torch
import time
from ultralytics import YOLO
import matplotlib.pyplot as plt
from pathlib import Path

class PotholeSegmentationTrainer:
    def __init__(self, dataset_path="pothole segmentation/Pothole_Segmentation_YOLOv8"):
        """Initialize segmentation trainer"""
        
        self.dataset_path = dataset_path
        self.data_yaml = os.path.join(dataset_path, "data.yaml")
        
        # Create output directories
        os.makedirs("trained_segmentation_models", exist_ok=True)
        os.makedirs("segmentation_results", exist_ok=True)
        
        print(f"🔧 Initializing Pothole Segmentation Training...")
        print(f"Dataset path: {self.dataset_path}")
        print(f"Data config: {self.data_yaml}")
        
        # Check dataset structure
        self.verify_dataset()
    
    def verify_dataset(self):
        """Verify dataset structure"""
        
        train_images = os.path.join(self.dataset_path, "train", "images")
        train_labels = os.path.join(self.dataset_path, "train", "labels")
        valid_images = os.path.join(self.dataset_path, "valid", "images")
        valid_labels = os.path.join(self.dataset_path, "valid", "labels")
        
        train_img_count = len([f for f in os.listdir(train_images) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]) if os.path.exists(train_images) else 0
        train_lbl_count = len([f for f in os.listdir(train_labels) if f.endswith('.txt')]) if os.path.exists(train_labels) else 0
        
        valid_img_count = len([f for f in os.listdir(valid_images) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]) if os.path.exists(valid_images) else 0
        valid_lbl_count = len([f for f in os.listdir(valid_labels) if f.endswith('.txt')]) if os.path.exists(valid_labels) else 0
        
        print(f"📊 Dataset Statistics:")
        print(f"   Training: {train_img_count} images, {train_lbl_count} labels")
        print(f"   Validation: {valid_img_count} images, {valid_lbl_count} labels")
        
        if train_img_count == 0 or valid_img_count == 0:
            print("❌ No images found in dataset!")
            return False
        
        return True
    
    def update_data_yaml(self):
        """Update data.yaml with correct paths"""
        
        yaml_content = f"""
# Pothole Segmentation Dataset Configuration
train: {os.path.abspath(os.path.join(self.dataset_path, "train", "images"))}
val: {os.path.abspath(os.path.join(self.dataset_path, "valid", "images"))}

# Number of classes
nc: 1

# Class names
names: ['pothole']

# Dataset info
path: {os.path.abspath(self.dataset_path)}
"""
        
        config_path = "pothole_segmentation_config.yaml"
        with open(config_path, 'w') as f:
            f.write(yaml_content.strip())
        
        print(f"📝 Updated configuration: {config_path}")
        return config_path
    
    def train_segmentation_model(self, epochs=100, img_size=640):
        """Train YOLOv8 segmentation model"""
        
        print(f"🚀 Starting YOLOv8 Segmentation Training...")
        print(f"   Epochs: {epochs}")
        print(f"   Image size: {img_size}")
        print(f"   Device: {'CUDA' if torch.cuda.is_available() else 'CPU'}")
        
        # Update data configuration
        config_path = self.update_data_yaml()
        
        # Load YOLOv8 segmentation model
        model = YOLO('yolov8n-seg.pt')  # Start with nano segmentation model
        
        # Train the model
        print("🔥 Training in progress...")
        start_time = time.time()
        
        try:
            results = model.train(
                data=config_path,
                epochs=epochs,
                imgsz=img_size,
                device='cuda' if torch.cuda.is_available() else 'cpu',
                project='runs/segment',
                name='pothole_segmentation',
                exist_ok=True,
                save=True,
                plots=True,
                patience=20,
                save_period=10,
                val=True,
                batch=4 if torch.cuda.is_available() else 2,
                workers=4,
                optimizer='Adam',
                lr0=0.01,
                weight_decay=0.0005,
                momentum=0.937,
                warmup_epochs=3.0,
                warmup_momentum=0.8,
                warmup_bias_lr=0.1,
                cos_lr=True,
                close_mosaic=10,
                amp=True,
                fraction=1.0,
                profile=False,
                freeze=None,
                multi_scale=True,
                overlap_mask=True,
                mask_ratio=4,
                dropout=0.0,
                verbose=True
            )
            
            training_time = time.time() - start_time
            
            print(f"✅ Training completed successfully!")
            print(f"   Training time: {training_time/60:.1f} minutes")
            print(f"   Model saved in: runs/segment/pothole_segmentation/")
            
            # Copy best model to our directory
            best_model_path = "runs/segment/pothole_segmentation/weights/best.pt"
            if os.path.exists(best_model_path):
                import shutil
                shutil.copy(best_model_path, "trained_segmentation_models/pothole_segmentation_best.pt")
                print(f"   Best model copied to: trained_segmentation_models/pothole_segmentation_best.pt")
            
            return model, results
            
        except Exception as e:
            print(f"❌ Training failed: {e}")
            return None, None
    
    def test_trained_model(self, model_path="trained_segmentation_models/pothole_segmentation_best.pt"):
        """Test the trained segmentation model"""
        
        if not os.path.exists(model_path):
            model_path = "runs/segment/pothole_segmentation/weights/best.pt"
        
        if not os.path.exists(model_path):
            print(f"❌ No trained model found at {model_path}")
            return None
        
        print(f"🧪 Testing trained segmentation model: {model_path}")
        
        # Load trained model
        model = YOLO(model_path)
        
        # Test on validation images
        valid_images_path = os.path.join(self.dataset_path, "valid", "images")
        
        if not os.path.exists(valid_images_path):
            print("❌ No validation images found")
            return None
        
        image_files = [f for f in os.listdir(valid_images_path) if f.lower().endswith(('.jpg', '.jpeg', '.png'))][:5]  # Test first 5 images
        
        results = []
        
        for img_file in image_files:
            img_path = os.path.join(valid_images_path, img_file)
            print(f"   Testing: {img_file}")
            
            # Run inference
            pred_results = model.predict(img_path, conf=0.3, save=False, show=False, verbose=False)
            
            # Process results
            if len(pred_results) > 0 and pred_results[0].masks is not None:
                result = pred_results[0]
                masks = result.masks.data.cpu().numpy()
                boxes = result.boxes.xyxy.cpu().numpy()
                scores = result.boxes.conf.cpu().numpy()
                
                print(f"      Found {len(masks)} segmented potholes")
                
                # Save visualization
                annotated_img = result.plot()
                output_path = f"segmentation_results/test_{img_file}"
                cv2.imwrite(output_path, annotated_img)
                
                results.append({
                    'image': img_file,
                    'pothole_count': len(masks),
                    'confidence_scores': scores.tolist(),
                    'output_path': output_path
                })
            else:
                print(f"      No potholes detected")
                results.append({
                    'image': img_file,
                    'pothole_count': 0,
                    'confidence_scores': [],
                    'output_path': None
                })
        
        print(f"✅ Testing completed! Results saved in segmentation_results/")
        return results

def main():
    """Main training function"""
    
    print("🔍 POTHOLE SEGMENTATION MODEL TRAINING")
    print("=" * 60)
    
    trainer = PotholeSegmentationTrainer()
    
    # Train the model
    model, training_results = trainer.train_segmentation_model(epochs=50, img_size=640)
    
    if model:
        print("\n🧪 Testing trained model...")
        test_results = trainer.test_trained_model()
        
        if test_results:
            print("\n📈 Test Results Summary:")
            total_detections = sum(r['pothole_count'] for r in test_results)
            print(f"   Total potholes detected: {total_detections}")
            print(f"   Images processed: {len(test_results)}")
            print(f"   Average detections per image: {total_detections/len(test_results):.1f}")
    
    print("\n✅ TRAINING PROCESS COMPLETE!")
    print("Your segmentation model is ready for use!")

if __name__ == "__main__":
    main()
