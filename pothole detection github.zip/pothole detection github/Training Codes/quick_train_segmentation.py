#!/usr/bin/env python3
"""
Quick Segmentation Training - Optimized for faster training
"""

import os
import cv2
import numpy as np
import torch
import time
from ultralytics import YOLO

class QuickSegmentationTrainer:
    def __init__(self):
        self.dataset_path = "pothole segmentation/Pothole_Segmentation_YOLOv8"
        
        # Create directories
        os.makedirs("trained_segmentation_models", exist_ok=True)
        os.makedirs("quick_results", exist_ok=True)
        
        print("🚀 Quick Segmentation Training")
        print("=" * 40)
        
    def create_config(self):
        """Create training config"""
        config = f"""
train: {os.path.abspath(os.path.join(self.dataset_path, "train", "images"))}
val: {os.path.abspath(os.path.join(self.dataset_path, "valid", "images"))}
nc: 1
names: ['pothole']
"""
        with open("quick_config.yaml", "w") as f:
            f.write(config.strip())
        return "quick_config.yaml"
    
    def train_quick(self):
        """Quick training with optimized settings"""
        print("🔥 Starting quick training (20 epochs)...")
        
        config = self.create_config()
        
        # Load pre-trained segmentation model
        model = YOLO('yolov8n-seg.pt')
        
        try:
            # Quick training with minimal epochs
            results = model.train(
                data=config,
                epochs=20,  # Reduced epochs
                imgsz=416,  # Smaller image size for speed
                batch=4 if torch.cuda.is_available() else 2,
                device='cuda' if torch.cuda.is_available() else 'cpu',
                project='quick_segment',
                name='pothole',
                exist_ok=True,
                save=True,
                patience=5,  # Early stopping
                save_period=5,
                plots=False,  # Disable plots for speed
                verbose=False,
                workers=2,
                cache=True,  # Cache images for speed
                amp=True,  # Mixed precision
                cos_lr=True,
                warmup_epochs=1,
                close_mosaic=5
            )
            
            print("✅ Quick training completed!")
            
            # Copy model
            best_path = "quick_segment/pothole/weights/best.pt"
            if os.path.exists(best_path):
                import shutil
                shutil.copy(best_path, "trained_segmentation_models/quick_segmentation.pt")
                print(f"Model saved: trained_segmentation_models/quick_segmentation.pt")
            
            return True
            
        except Exception as e:
            print(f"Training error: {e}")
            return False
    
    def test_model(self):
        """Test the trained model"""
        model_path = "trained_segmentation_models/quick_segmentation.pt"
        
        if not os.path.exists(model_path):
            model_path = "quick_segment/pothole/weights/best.pt"
        
        if not os.path.exists(model_path):
            print("❌ No model found")
            return False
        
        print("🧪 Testing model...")
        model = YOLO(model_path)
        
        # Test on a few validation images
        val_path = os.path.join(self.dataset_path, "valid", "images")
        images = [f for f in os.listdir(val_path) if f.lower().endswith(('.jpg', '.png'))][:3]
        
        for img in images:
            img_path = os.path.join(val_path, img)
            results = model.predict(img_path, conf=0.3, save=False)
            
            if results[0].masks is not None:
                print(f"   {img}: {len(results[0].masks)} potholes detected")
                
                # Save result
                annotated = results[0].plot()
                cv2.imwrite(f"quick_results/result_{img}", annotated)
            else:
                print(f"   {img}: No potholes detected")
        
        print("✅ Testing completed! Check quick_results/ folder")
        return True

def main():
    trainer = QuickSegmentationTrainer()
    
    # Quick training
    if trainer.train_quick():
        # Test the model
        trainer.test_model()
        print("\n🎉 Success! Your segmentation model is ready!")
        print("Model location: trained_segmentation_models/quick_segmentation.pt")
    else:
        print("❌ Training failed")

if __name__ == "__main__":
    main()
