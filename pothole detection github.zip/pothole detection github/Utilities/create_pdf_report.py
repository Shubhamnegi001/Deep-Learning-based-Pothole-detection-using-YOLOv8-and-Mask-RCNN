#!/usr/bin/env python3
"""
Create PDF Report from Markdown
"""

import os
from datetime import datetime

def create_pdf_report():
    """Create a PDF version of the project report"""
    
    print("PDF REPORT GENERATOR")
    print("=" * 30)
    
    # Check if markdown report exists
    md_path = "project_report/PROJECT_REPORT.md"
    if not os.path.exists(md_path):
        print("Markdown report not found. Run simple_report_generator.py first.")
        return False
    
    try:
        # Try to use pandoc if available
        import subprocess
        
        pdf_path = "project_report/PROJECT_REPORT.pdf"
        
        print("Attempting to convert markdown to PDF using pandoc...")
        
        cmd = [
            "pandoc",
            md_path,
            "-o", pdf_path,
            "--pdf-engine=xelatex",
            "-V", "geometry:margin=1in",
            "-V", "fontsize=11pt",
            "--toc",
            "--highlight-style=tango"
        ]
        
        result = subprocess.run(cmd, capture_output=True, text=True)
        
        if result.returncode == 0:
            print(f"SUCCESS: PDF report created: {pdf_path}")
            return True
        else:
            print(f"Pandoc error: {result.stderr}")
            print("Trying alternative method...")
            
    except Exception as e:
        print(f"Pandoc not available: {e}")
        print("Trying alternative method...")
    
    # Try reportlab method
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet
        from reportlab.lib.units import inch
        
        print("Using ReportLab for PDF generation...")
        
        # Read markdown content
        with open(md_path, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Create PDF
        pdf_path = "project_report/PROJECT_REPORT.pdf"
        doc = SimpleDocTemplate(pdf_path, pagesize=letter)
        
        styles = getSampleStyleSheet()
        story = []
        
        # Convert markdown to simple paragraphs
        lines = content.split('\n')
        
        for line in lines:
            if line.strip():
                if line.startswith('# '):
                    # Main title
                    story.append(Paragraph(line[2:], styles['Title']))
                    story.append(Spacer(1, 0.2*inch))
                elif line.startswith('## '):
                    # Section header
                    story.append(Paragraph(line[3:], styles['Heading1']))
                    story.append(Spacer(1, 0.1*inch))
                elif line.startswith('### '):
                    # Subsection header  
                    story.append(Paragraph(line[4:], styles['Heading2']))
                    story.append(Spacer(1, 0.05*inch))
                elif line.startswith('- ') or line.startswith('* '):
                    # Bullet point
                    story.append(Paragraph(f"• {line[2:]}", styles['Normal']))
                elif line.startswith('**') and line.endswith('**'):
                    # Bold text
                    story.append(Paragraph(f"<b>{line[2:-2]}</b>", styles['Normal']))
                else:
                    # Regular paragraph
                    if not line.startswith('```') and not line.startswith('|'):
                        story.append(Paragraph(line, styles['Normal']))
                        story.append(Spacer(1, 0.05*inch))
        
        doc.build(story)
        print(f"SUCCESS: PDF report created: {pdf_path}")
        return True
        
    except Exception as e:
        print(f"ReportLab error: {e}")
        print("PDF generation failed. The markdown report is available.")
        return False

def main():
    success = create_pdf_report()
    
    if success:
        print("\nPDF report successfully generated!")
    else:
        print("\nPDF generation failed, but you have the markdown report.")
        
    print("\nAvailable reports:")
    print("- project_report/PROJECT_REPORT.md (Markdown)")
    if os.path.exists("project_report/PROJECT_REPORT.pdf"):
        print("- project_report/PROJECT_REPORT.pdf (PDF)")
    print("- project_report/project_metrics.json (Metrics)")

if __name__ == "__main__":
    main()
