#!/usr/bin/env python3
"""
Simple Frontend Launcher
"""

import subprocess
import sys
import os

def main():
    print("POTHOLE DETECTION SYSTEM")
    print("Frontend Launcher")
    print("=" * 30)
    
    # Check if frontend file exists
    if not os.path.exists("complete_pothole_frontend.py"):
        print("Error: Frontend file not found!")
        print("Make sure 'complete_pothole_frontend.py' is in the current directory.")
        return
    
    print("Launching Streamlit frontend...")
    print("The web interface will open in your browser.")
    print("If it doesn't open automatically, go to: http://localhost:8501")
    print("\nPress Ctrl+C to stop the server.\n")
    
    try:
        # Launch Streamlit
        subprocess.run([
            sys.executable, "-m", "streamlit", "run", 
            "complete_pothole_frontend.py",
            "--server.port", "8501"
        ])
        
    except KeyboardInterrupt:
        print("\nFrontend stopped by user")
    except Exception as e:
        print(f"Error launching frontend: {e}")
        print("\nTrying alternative command...")
        try:
            subprocess.run(["streamlit", "run", "complete_pothole_frontend.py"])
        except:
            print("Failed. Please install streamlit: pip install streamlit")

if __name__ == "__main__":
    main()
