#!/usr/bin/env python3
"""
Test Segmentation Model - Quick test of trained segmentation
"""

import cv2
import os
from ultralytics import YOLO
import numpy as np

def test_segmentation():
    """Test the trained segmentation model"""
    
    print("🧪 Testing Trained Segmentation Model")
    print("=" * 40)
    
    # Find segmentation model
    model_paths = [
        "trained_segmentation_models/quick_segmentation.pt",
        "quick_segment/pothole/weights/best.pt",
        "yolov8n-seg.pt"
    ]
    
    model_path = None
    for path in model_paths:
        if os.path.exists(path):
            model_path = path
            break
    
    if not model_path:
        print("❌ No segmentation model found!")
        return False
    
    print(f"📦 Loading model: {model_path}")
    model = YOLO(model_path)
    
    # Find test images
    test_dirs = [
        "pothole segmentation/Pothole_Segmentation_YOLOv8/valid/images",
        "quick_results",
        "."
    ]
    
    test_images = []
    for test_dir in test_dirs:
        if os.path.exists(test_dir):
            images = [f for f in os.listdir(test_dir) if f.lower().endswith(('.jpg', '.jpeg', '.png'))]
            for img in images[:3]:  # Take first 3 images
                test_images.append(os.path.join(test_dir, img))
    
    if not test_images:
        print("❌ No test images found!")
        return False
    
    print(f"🖼️ Found {len(test_images)} test images")
    
    # Create results directory
    os.makedirs("model_test_results", exist_ok=True)
    
    # Test each image
    total_detections = 0
    for i, img_path in enumerate(test_images):
        print(f"\n🔍 Testing image {i+1}: {os.path.basename(img_path)}")
        
        # Load image
        image = cv2.imread(img_path)
        if image is None:
            print(f"   ⚠️ Could not load image")
            continue
        
        # Run inference
        results = model.predict(img_path, conf=0.3, save=False, show=False, verbose=False)
        
        if len(results) == 0:
            print(f"   📊 No results returned")
            continue
        
        result = results[0]
        
        # Check for segmentation masks
        if result.masks is None:
            print(f"   📊 No segmentation masks found")
            continue
        
        masks = result.masks.data.cpu().numpy()
        boxes = result.boxes.xyxy.cpu().numpy()
        scores = result.boxes.conf.cpu().numpy()
        
        num_detections = len(masks)
        total_detections += num_detections
        
        print(f"   ✅ Found {num_detections} segmented potholes")
        
        # Calculate areas
        total_area = 0
        for j, (mask, score) in enumerate(zip(masks, scores)):
            # Resize mask if needed
            if mask.shape != image.shape[:2]:
                mask = cv2.resize(mask.astype(np.uint8), (image.shape[1], image.shape[0]))
            
            mask_area = np.sum(mask > 0.5)
            total_area += mask_area
            area_cm2 = mask_area / 120  # Rough conversion
            
            print(f"      Pothole {j+1}: {mask_area:,} pixels ({area_cm2:.1f} cm²), confidence: {score:.3f}")
        
        print(f"   📏 Total area: {total_area:,} pixels ({total_area/120:.1f} cm²)")
        
        # Save annotated result
        annotated = result.plot()
        output_path = f"model_test_results/test_{os.path.basename(img_path)}"
        cv2.imwrite(output_path, annotated)
        print(f"   💾 Result saved: {output_path}")
    
    print(f"\n📈 SUMMARY:")
    print(f"   Total images tested: {len(test_images)}")
    print(f"   Total potholes detected: {total_detections}")
    print(f"   Average per image: {total_detections/len(test_images):.1f}")
    print(f"   Results saved in: model_test_results/")
    
    return True

def main():
    if test_segmentation():
        print("\n🎉 Model test completed successfully!")
        print("Check 'model_test_results/' folder for results")
    else:
        print("\n❌ Model test failed")

if __name__ == "__main__":
    main()
