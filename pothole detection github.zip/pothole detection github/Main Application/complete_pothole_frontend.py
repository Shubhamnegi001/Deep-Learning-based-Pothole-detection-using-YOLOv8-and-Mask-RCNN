#!/usr/bin/env python3
"""
Complete Pothole Detection & Segmentation Frontend
Streamlit web application with trained segmentation model
"""

import streamlit as st
import cv2
import numpy as np
import os
import time
from pathlib import Path
import json
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from ultralytics import YOLO
from PIL import Image
import io
import base64

class PotholeDetectionApp:
    def __init__(self):
        """Initialize the pothole detection app"""
        
        self.setup_models()
        self.create_directories()
        
        # App configuration
        self.confidence_threshold = 0.3
        self.results_history = []
        
    def setup_models(self):
        """Setup detection and segmentation models"""
        
        # Detection model paths (in order of preference)
        detection_paths = [
            "runs/detect/pothole_final/weights/best.pt",
            "runs/detect/pothole_yolo/weights/best.pt", 
            "yolov8n.pt"
        ]
        
        # Segmentation model paths (in order of preference)
        segmentation_paths = [
            "trained_segmentation_models/quick_segmentation.pt",
            "quick_segment/pothole/weights/best.pt",
            "yolov8n-seg.pt"
        ]
        
        # Load detection model
        self.detection_model = None
        for path in detection_paths:
            if os.path.exists(path):
                try:
                    self.detection_model = YOLO(path)
                    self.detection_model_name = path
                    break
                except:
                    continue
        
        # Load segmentation model
        self.segmentation_model = None
        for path in segmentation_paths:
            if os.path.exists(path):
                try:
                    self.segmentation_model = YOLO(path)
                    self.segmentation_model_name = path
                    break
                except:
                    continue
    
    def create_directories(self):
        """Create necessary directories"""
        os.makedirs("frontend_results", exist_ok=True)
        os.makedirs("uploaded_images", exist_ok=True)
        os.makedirs("static/temp", exist_ok=True)
    
    def process_detection(self, image, confidence=0.3):
        """Process image for pothole detection"""
        
        if self.detection_model is None:
            return None
        
        start_time = time.time()
        results = self.detection_model.predict(
            image, 
            conf=confidence, 
            save=False, 
            show=False, 
            verbose=False
        )
        processing_time = time.time() - start_time
        
        if len(results) == 0 or results[0].boxes is None:
            return {
                'detections': [],
                'processing_time': processing_time,
                'annotated_image': image,
                'model_used': 'detection'
            }
        
        result = results[0]
        boxes = result.boxes.xyxy.cpu().numpy()
        confidences = result.boxes.conf.cpu().numpy()
        
        detections = []
        for i, (box, conf) in enumerate(zip(boxes, confidences)):
            x1, y1, x2, y2 = [int(x) for x in box]
            bbox_area = (x2-x1) * (y2-y1)
            
            detections.append({
                'id': i + 1,
                'bbox': [x1, y1, x2, y2],
                'confidence': float(conf),
                'area_pixels': int(bbox_area),
                'area_cm2': float(bbox_area / 120),  # Rough conversion
                'area_m2': float(bbox_area / 120000)
            })
        
        # Create annotated image
        annotated_image = result.plot()
        
        return {
            'detections': detections,
            'processing_time': processing_time,
            'annotated_image': annotated_image,
            'model_used': 'detection',
            'total_potholes': len(detections)
        }
    
    def process_segmentation(self, image, confidence=0.3):
        """Process image for pothole segmentation"""
        
        if self.segmentation_model is None:
            return None
        
        start_time = time.time()
        results = self.segmentation_model.predict(
            image, 
            conf=confidence, 
            save=False, 
            show=False, 
            verbose=False
        )
        processing_time = time.time() - start_time
        
        if len(results) == 0 or results[0].masks is None:
            return {
                'detections': [],
                'processing_time': processing_time,
                'annotated_image': image,
                'model_used': 'segmentation'
            }
        
        result = results[0]
        masks = result.masks.data.cpu().numpy()
        boxes = result.boxes.xyxy.cpu().numpy()
        confidences = result.boxes.conf.cpu().numpy()
        
        detections = []
        total_mask_area = 0
        
        for i, (mask, box, conf) in enumerate(zip(masks, boxes, confidences)):
            x1, y1, x2, y2 = [int(x) for x in box]
            
            # Calculate mask area
            if mask.shape != image.shape[:2]:
                mask_resized = cv2.resize(mask.astype(np.uint8), (image.shape[1], image.shape[0]))
            else:
                mask_resized = mask
            
            mask_area = np.sum(mask_resized > 0.5)
            total_mask_area += mask_area
            
            detections.append({
                'id': i + 1,
                'bbox': [x1, y1, x2, y2],
                'confidence': float(conf),
                'mask_area_pixels': int(mask_area),
                'surface_area_cm2': float(mask_area / 120),  # Accurate segmentation area
                'surface_area_m2': float(mask_area / 120000),
                'fill_ratio': float(mask_area / ((x2-x1) * (y2-y1))) if (x2-x1) * (y2-y1) > 0 else 0
            })
        
        # Create annotated image
        annotated_image = result.plot()
        
        return {
            'detections': detections,
            'processing_time': processing_time,
            'annotated_image': annotated_image,
            'model_used': 'segmentation',
            'total_potholes': len(detections),
            'total_surface_area_m2': float(total_mask_area / 120000)
        }
    
    def save_results(self, image, results, filename):
        """Save processing results"""
        
        if results is None:
            return None
        
        # Save annotated image
        timestamp = int(time.time())
        output_path = f"frontend_results/{timestamp}_{filename}"
        cv2.imwrite(output_path, results['annotated_image'])
        
        # Save results data
        results_data = {
            'filename': filename,
            'timestamp': timestamp,
            'model_used': results['model_used'],
            'processing_time': results['processing_time'],
            'total_potholes': results.get('total_potholes', 0),
            'detections': results['detections']
        }
        
        json_path = f"frontend_results/{timestamp}_{filename}_results.json"
        with open(json_path, 'w') as f:
            json.dump(results_data, f, indent=2)
        
        self.results_history.append(results_data)
        
        return output_path
    
    def create_summary_charts(self, results):
        """Create summary charts for results"""
        
        if not results or not results.get('detections'):
            return None, None
        
        detections = results['detections']
        
        # Confidence distribution
        confidences = [d['confidence'] for d in detections]
        fig_conf = px.histogram(
            x=confidences, 
            nbins=10,
            title="Detection Confidence Distribution",
            labels={'x': 'Confidence Score', 'y': 'Count'}
        )
        
        # Area distribution (if segmentation results)
        if results['model_used'] == 'segmentation':
            areas = [d.get('surface_area_cm2', 0) for d in detections]
            fig_area = px.bar(
                x=[f"Pothole {i+1}" for i in range(len(areas))],
                y=areas,
                title="Pothole Surface Areas",
                labels={'x': 'Pothole ID', 'y': 'Surface Area (cm²)'}
            )
        else:
            areas = [d.get('area_cm2', 0) for d in detections]
            fig_area = px.bar(
                x=[f"Pothole {i+1}" for i in range(len(areas))],
                y=areas,
                title="Estimated Pothole Areas",
                labels={'x': 'Pothole ID', 'y': 'Estimated Area (cm²)'}
            )
        
        return fig_conf, fig_area

def main():
    """Main Streamlit application"""
    
    # Page config
    st.set_page_config(
        page_title="Pothole Detection & Segmentation",
        page_icon="🛣️",
        layout="wide",
        initial_sidebar_state="expanded"
    )
    
    # Initialize app
    if 'app' not in st.session_state:
        st.session_state.app = PotholeDetectionApp()
    
    app = st.session_state.app
    
    # Title and description
    st.title("🛣️ Pothole Detection & Segmentation System")
    st.markdown("---")
    
    # Sidebar
    st.sidebar.title("⚙️ Settings")
    
    # Model status
    st.sidebar.markdown("### 🤖 Model Status")
    if app.detection_model:
        st.sidebar.success(f"✅ Detection: {os.path.basename(app.detection_model_name)}")
    else:
        st.sidebar.error("❌ No detection model")
    
    if app.segmentation_model:
        st.sidebar.success(f"✅ Segmentation: {os.path.basename(app.segmentation_model_name)}")
    else:
        st.sidebar.error("❌ No segmentation model")
    
    # Processing mode
    processing_mode = st.sidebar.selectbox(
        "Processing Mode",
        ["Detection Only", "Segmentation Only", "Both"],
        index=2
    )
    
    # Confidence threshold
    confidence = st.sidebar.slider(
        "Confidence Threshold",
        min_value=0.1,
        max_value=0.9,
        value=0.3,
        step=0.05
    )
    
    # Main content area
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.header("📁 Input")
        
        # File upload
        uploaded_file = st.file_uploader(
            "Choose an image...",
            type=['jpg', 'jpeg', 'png', 'bmp'],
            help="Upload a road image to detect and segment potholes"
        )
        
        if uploaded_file is not None:
            # Display uploaded image
            image = Image.open(uploaded_file)
            st.image(image, caption="Uploaded Image", use_column_width=True)
            
            # Convert to OpenCV format
            image_array = np.array(image)
            if len(image_array.shape) == 3:
                image_cv = cv2.cvtColor(image_array, cv2.COLOR_RGB2BGR)
            else:
                image_cv = image_array
            
            # Process button
            if st.button("🔍 Analyze Potholes", type="primary"):
                
                with st.spinner("Processing image..."):
                    results = {}
                    
                    # Detection
                    if processing_mode in ["Detection Only", "Both"] and app.detection_model:
                        with st.spinner("Running detection model..."):
                            detection_results = app.process_detection(image_cv, confidence)
                            results['detection'] = detection_results
                    
                    # Segmentation
                    if processing_mode in ["Segmentation Only", "Both"] and app.segmentation_model:
                        with st.spinner("Running segmentation model..."):
                            segmentation_results = app.process_segmentation(image_cv, confidence)
                            results['segmentation'] = segmentation_results
                    
                    # Store results in session state
                    st.session_state.current_results = results
                    st.session_state.current_image = image_cv
                    st.session_state.filename = uploaded_file.name
    
    with col2:
        st.header("📊 Results")
        
        if 'current_results' in st.session_state:
            results = st.session_state.current_results
            
            # Results tabs
            if len(results) > 1:
                tab1, tab2 = st.tabs(["🎯 Detection", "🎭 Segmentation"])
            else:
                tab1 = st.container()
            
            # Display detection results
            if 'detection' in results:
                with tab1 if len(results) > 1 else tab1:
                    det_results = results['detection']
                    if det_results and det_results['detections']:
                        st.success(f"🎯 Found {len(det_results['detections'])} potholes")
                        
                        # Show processed image
                        processed_img = cv2.cvtColor(det_results['annotated_image'], cv2.COLOR_BGR2RGB)
                        st.image(processed_img, caption="Detection Results", use_column_width=True)
                        
                        # Performance metrics
                        col_a, col_b = st.columns(2)
                        with col_a:
                            st.metric("Processing Time", f"{det_results['processing_time']:.2f}s")
                        with col_b:
                            total_area = sum(d['area_m2'] for d in det_results['detections'])
                            st.metric("Total Area", f"{total_area:.3f} m²")
                        
                        # Detection details
                        with st.expander("📋 Detection Details"):
                            for det in det_results['detections']:
                                st.write(f"**Pothole {det['id']}:**")
                                st.write(f"- Confidence: {det['confidence']:.2f}")
                                st.write(f"- Estimated Area: {det['area_cm2']:.1f} cm²")
                    else:
                        st.warning("🔍 No potholes detected")
            
            # Display segmentation results
            if 'segmentation' in results and len(results) > 1:
                with tab2:
                    seg_results = results['segmentation']
                    if seg_results and seg_results['detections']:
                        st.success(f"🎭 Segmented {len(seg_results['detections'])} potholes")
                        
                        # Show processed image
                        processed_img = cv2.cvtColor(seg_results['annotated_image'], cv2.COLOR_BGR2RGB)
                        st.image(processed_img, caption="Segmentation Results", use_column_width=True)
                        
                        # Performance metrics
                        col_a, col_b, col_c = st.columns(3)
                        with col_a:
                            st.metric("Processing Time", f"{seg_results['processing_time']:.2f}s")
                        with col_b:
                            st.metric("Total Surface Area", f"{seg_results.get('total_surface_area_m2', 0):.3f} m²")
                        with col_c:
                            avg_fill = np.mean([d['fill_ratio'] for d in seg_results['detections']])
                            st.metric("Avg Fill Ratio", f"{avg_fill:.2f}")
                        
                        # Segmentation details
                        with st.expander("📋 Segmentation Details"):
                            for det in seg_results['detections']:
                                st.write(f"**Pothole {det['id']}:**")
                                st.write(f"- Confidence: {det['confidence']:.2f}")
                                st.write(f"- Surface Area: {det['surface_area_cm2']:.1f} cm²")
                                st.write(f"- Fill Ratio: {det['fill_ratio']:.2f}")
                    else:
                        st.warning("🎭 No potholes segmented")
            
            # Charts section
            st.markdown("---")
            st.subheader("📈 Analysis Charts")
            
            # Create charts for the primary result
            primary_results = results.get('segmentation', results.get('detection'))
            if primary_results:
                fig_conf, fig_area = app.create_summary_charts(primary_results)
                
                if fig_conf and fig_area:
                    chart_col1, chart_col2 = st.columns(2)
                    with chart_col1:
                        st.plotly_chart(fig_conf, use_container_width=True)
                    with chart_col2:
                        st.plotly_chart(fig_area, use_container_width=True)
            
            # Save results button
            if st.button("💾 Save Results"):
                with st.spinner("Saving results..."):
                    for result_type, result_data in results.items():
                        if result_data:
                            output_path = app.save_results(
                                st.session_state.current_image, 
                                result_data, 
                                f"{result_type}_{st.session_state.filename}"
                            )
                            if output_path:
                                st.success(f"✅ {result_type.title()} results saved!")
        
        else:
            st.info("👆 Upload an image and click 'Analyze Potholes' to see results")
    
    # Footer
    st.markdown("---")
    st.markdown("### 📊 System Information")
    
    col_a, col_b, col_c = st.columns(3)
    with col_a:
        if app.detection_model:
            st.info("🎯 Detection Model Ready")
        else:
            st.error("❌ No Detection Model")
    
    with col_b:
        if app.segmentation_model:
            st.success("🎭 Segmentation Model Trained")
        else:
            st.error("❌ No Segmentation Model")
    
    with col_c:
        results_count = len(app.results_history)
        st.metric("Images Processed", results_count)

if __name__ == "__main__":
    main()
